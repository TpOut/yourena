//
// Created by Jesson on 2019-02-12.
//

#ifndef CPLUSPLUS_静态_H
#define CPLUSPLUS_静态_H


class 静态 {
public:
    static 静态* getInstance();

private:
    static 静态* instance;
};


#endif //CPLUSPLUS_静态_H
