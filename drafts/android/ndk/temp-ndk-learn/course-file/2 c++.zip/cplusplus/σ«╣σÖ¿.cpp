//
// Created by Jesson on 2019-01-22.
//

#include <vector>
#include <queue>
#include <string.h>
#include <iostream>
#include <stack>


using namespace std;

//int main(){
//    //实例化
//    vector<int> vec1;//默认初始化，vec1为空
//    vector<int> vec2(vec1);//使用vec1初始化vec2
//    vector<int> vec3(vec1.begin(),vec1.end());//使用vec1初始化vec2
//    vector<int> vec4(10);//10个值为0的元素
//    vector<int> vec5(10,4);//10个值为4的元素
//    vector<string> vec6(10);//10个值为null的元素
//    cout<<"获取容器容量大小"<<vec5.capacity()<<endl;
//
//    vec5.cbegin(); //编译器要实现c++11
//
//
//    vec5.push_back(100);
//    vec5.push_back(101);
//
//    cout<<"获取容器容量大小"<<vec5.capacity()<<endl;
//    cout<<"获取下标元素"<<vec5[0]<<endl;
//    cout<<"获取下标元素"<<vec5[11]<<endl;
//
//    //注意C++在语法层面没有规定vector内部缓冲区提前增加容量的大小 这取决于STL的实现
//
//
//    vec5.front();
//    vec5.end();
//    vec5.clear();
//    vec5.erase(vec5.begin(),vec5.end());
//
//    vec5.size();//元素的个数
//
//    cout<<"获取容器容量大小"<<vec5.capacity()<<endl;//思考这个数据 怎么让容量是0
//
//    vector<int>().swap(vec5);
//    cout<<"获取容器容量大小"<<vec5.capacity()<<endl;
//
//    return -1;
//}

//------------自适应容器--------------------------LIFO----------

//int main(){
//    //实例化
//    stack<int> stack1;
//    stack<vector<int>> stack2;
//    stack<int> stack3(stack1);
//
//    stack1.push(1);
//    stack1.push(11);
//    stack1.push(111);
//    stack1.push(1111);
//
//    while (stack1.size()>0){
//        cout<<"top-"<<stack1.top()<<endl;
//        stack1.pop();
//    }
//    stack1.empty();
//
//
//    queue<int> queue1;
//    queue1.push(100);
//    queue1.push(200);
//
//    queue1.pop();
//    queue1.size();
//
//
//    priority_queue<string,vector<string>,less<string>> priority_queue1;
//    priority_queue1.push("abs");
//    priority_queue1.push("ccc");
//    priority_queue1.push("ddd");
//    priority_queue1.push("wqwqw");
//    while(!priority_queue1.empty()){
//        cout<<"top-"<<priority_queue1.top()<<endl;
//        priority_queue1.pop();
//    }
//}



//------------思考----------
class Person{
public:
    int age;
    bool isFemale;

    bool operator< (const Person& anotherperson )const
    {
        bool flag = false;
        if(age){
            return true;
        }else{
            return false;
        }
    }
};

//优先队列实现老人和妇女优先



struct cmp{
    bool operator()(Person x,Person y)
    {
        if(!x.isFemale&&(y.age>=60||y.isFemale)){
            return true;
        }else{
            return false;
        }
    }
};


int main(){
    Person person;
    person.age = 30;
    person.isFemale = true;

    Person person1;
    person.age = 60;
    person.isFemale = true;

    Person person2;
    person.age = 20;
    person.isFemale = false;
    Person person3;

    person.age = 70;
    person.isFemale = false;

    priority_queue<Person,vector<Person>,cmp> priority_queue1;
    priority_queue1.push(person);
    priority_queue1.push(person1);
    priority_queue1.push(person2);
    priority_queue1.push(person3);

    while(!priority_queue1.empty()){
        cout<<"top-"<< priority_queue1.top().age<<endl;
        priority_queue1.pop();
    }

}