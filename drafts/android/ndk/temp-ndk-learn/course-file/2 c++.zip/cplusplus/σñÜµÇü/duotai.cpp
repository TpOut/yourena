//多态就是程序运行时，父类指针可以根据具体指向的子类对象，来执行不同的函数，表现为多态。
/***
- 当类中存在虚函数时，编译器会在类中自动生成一个虚函数表
- 虚函数表是一个存储类成员函数指针的数据结构
- 虚函数表由编译器自动生成和维护
- virtual 修饰的成员函数会被编译器放入虚函数表中
- 存在虚函数时，编译器会为对象自动生成一个指向虚函数表的指针（通常称之为 vptr 指针）
 ***/

#include <iostream>

using namespace std;

//class Parent {
//public:
//    // 父类虚函数必须要有 virtual 关键字
//    virtual void fun() {
//        cout << "父类" << endl;
//    }
//};
//
//class Child : public Parent {
//public:
//    // 子类有没有 virtual 关键字都可以
//    void fun() {
//        cout << "子类" << endl;
//    }
//};
//
//int main() {
//    Parent *p = NULL; // 创建一个父类的指针
//    Parent parent;
//    Child child;
//    p = &parent; // 指向父类的对象
//    p->fun(); // 执行的是父类的 fun() 函数
//    p = &child; // 指向子类的对象
//    p->fun(); // 执行的是子类的 fun() 函数
//
//    return 0;
//}

//在父类中去调用子类的虚函数能实现多态吗？

class Parent
{
public:
    Parent()
    {
        // 父类的构造方法中执行虚函数，会发生多态吗？
        fun();
    }
    virtual void fun()
    {
        cout << "父类" << endl;
    }
};
class Child : public Parent
{
public:
    Child()
    {
        fun();
    }
    void fun()
    {
        cout << "子类" << endl;
    }
};

int main() {
    Child c;
   // c.fun();
    Parent* parent;
    parent = &c;
    parent->fun();
    return 0;
}
